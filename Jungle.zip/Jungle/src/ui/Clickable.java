package ui;

public interface Clickable {
	public void onClick();
}
