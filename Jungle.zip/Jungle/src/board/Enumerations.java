package board;

public class Enumerations {
	public enum Rank {
		mouse,
		cat,
		dog,
		wolf,
		leopard,
		tiger,
		lion,
		elephant,
		empty
	}
	
	public enum Landscape {
		land,
		water,
		trap1,
		trap2,
		den1,
		den2
	}
}
