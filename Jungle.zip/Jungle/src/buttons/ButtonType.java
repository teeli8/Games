package buttons;

public enum ButtonType {
	start,
	reload,
	exit,
	save,
	restart,
	back,
	customize,
	finish,
	rule,
	next,
	ret,
}
